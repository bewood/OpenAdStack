//v.3.0 build 110713

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dataProcessor.prototype.setOnAfterUpdate=function(a){this.attachEvent("onAfterUpdate",a)};dataProcessor.prototype.enableDebug=function(){};dataProcessor.prototype.setOnBeforeUpdateHandler=function(a){this.attachEvent("onBeforeDataSending",a)};

//v.3.0 build 110713

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/